import * as React from 'react';
import Box from '@mui/material/Box';
import Tabs from '@mui/material/Tabs';
import Tab from '@mui/material/Tab';
import { Navigate  } from 'react-router-dom'
import Link from '@mui/material/Link';
import {Link as Href} from 'react-router-dom'
export default function Navbar() {
   

  
  return (
     
    <Box sx={{ width: '100%', bgcolor: 'background.paper' }}>
      <Tabs  centered>
        <Link component="button" variant="body2" sx={{mx:3}} ><Href to="/">Home</Href></Link>
        <Link component="button" variant="body2" sx={{mx:3}}   ><Href to="/account">Login</Href></Link>
        <Link component="button" variant="body2" sx={{mx:3}}   ><Href to="/account">Register</Href></Link>
      </Tabs>
    </Box>
  );
}

